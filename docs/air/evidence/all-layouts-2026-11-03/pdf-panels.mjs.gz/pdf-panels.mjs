import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
const {chromium,webkit}=await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const repo=process.env.PDF_REPO || process.cwd();
const names=[...(await readFile(`${repo}/src/editor/tools.ts`,'utf8')).matchAll(/name: "([^"]+)"/g)].map(m=>m[1]);
const sizes=JSON.parse(process.env.AIR_PROFILES||'[[320,568,16],[375,812,16],[390,844,16],[430,932,16],[844,390,16],[768,1024,16],[1024,768,16],[1280,720,16],[1366,768,16],[1440,900,16],[1920,1080,16],[390,844,32],[1024,768,32],[1440,900,32]]');
const engine=process.env.AIR_BROWSER||'chromium';
const out=process.env.AIR_EVIDENCE_DIR||`/tmp/air-all-layouts-2026-11-03/pdf-${engine}`;
await mkdir(out,{recursive:true});
const browser=await(engine==='webkit'?webkit.launch():chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}));
const results=[],errors=[],failures=[];
try {
 for(const [width,height,font] of sizes)for(const theme of ['light','dark']){
  const p=await browser.newPage({viewport:{width,height},hasTouch:width<1100,colorScheme:theme,reducedMotion:'reduce',serviceWorkers:'block'});
  p.on('pageerror',e=>errors.push({width,height,font,theme,error:e.message}));
  p.setDefaultTimeout(15000);
  await p.goto(process.env.BASE_URL||'https://pdf.cloakyard.com');
  if(font!==16)await p.addStyleTag({content:`html{font-size:${font}px}`});
  await p.locator('input[type=file]').first().setInputFiles(`${repo}/tests/fixtures/multipage.pdf`);
  await p.getByRole('button',{name:'Export',exact:true}).waitFor();
  await p.locator('.editor-toolrail,.editor-mobile-sheet').first().waitFor();
  const mobile=await p.locator('.editor-mobile-sheet').count()>0;
  for(const name of names){
   if(mobile){
    const cancel=p.locator('.air-editor-actions button[aria-label="Cancel"]');
    const close=p.locator('.air-editor-actions button[aria-label="Close"]');
    if(await cancel.count())await cancel.click();else if(await close.count())await close.click();
    const picker=p.getByRole('button',{name:'Open tools',exact:true});
    if(await picker.isVisible())await picker.click();
    await p.locator('.editor-mobile-sheet').getByRole('button',{name,exact:true}).click();
   }else await p.locator('.editor-toolrail').getByRole('button',{name,exact:true}).click();
   const panel=p.locator('.editor-properties__body,.editor-mobile-sheet__body');
   await p.waitForFunction(()=>document.querySelector('.editor-properties__body,.editor-mobile-sheet__body')?.textContent.trim().length>0);
   await p.waitForFunction(()=>!/(Reading (?:document (?:properties|fields)|attachments|form fields|page text)|Scanning for hidden data)…/.test(document.querySelector('.editor-properties__body,.editor-mobile-sheet__body')?.textContent||''));
   await p.waitForTimeout(100);
   const proof=await p.evaluate(()=>{
    const host=document.querySelector('.editor-properties,.editor-mobile-sheet');
    const panel=host.querySelector('.editor-properties__body,.editor-mobile-sheet__body');
    const bounds=panel.getBoundingClientRect();
    const visible=e=>{const b=e.getBoundingClientRect(),s=getComputedStyle(e);return b.width>1&&b.height>1&&s.visibility!=='hidden'&&s.opacity!=='0'&&!e.closest('[hidden],[aria-hidden=true],.sr-only');};
    const issues=[];
    const label=e=>e.getAttribute('aria-label')||e.labels?.[0]?.textContent?.trim()||e.textContent?.trim()||e.outerHTML.slice(0,90);
    if(document.documentElement.scrollWidth>innerWidth+1)issues.push(['page overflow',document.documentElement.scrollWidth]);
    if(bounds.width<1||bounds.height<1)issues.push(['unreachable controls',bounds.width,bounds.height]);
    for(const e of panel.querySelectorAll('button,input,textarea,select,[role=slider]')){
     if(!visible(e))continue;
     const b=e.getBoundingClientRect();
     if(b.left<bounds.left-1||b.right>bounds.right+1)issues.push(['control outside panel',label(e),Math.round(b.left),Math.round(b.right)]);
     const target=e.matches('input[type=radio],input[type=checkbox]')?(e.closest('label')||e):e;
     const t=target.getBoundingClientRect(),minimum=matchMedia('(pointer:coarse)').matches?44:32;
     if(t.width<minimum-1||t.height<minimum-1)issues.push(['small target',label(e),Math.round(t.width),Math.round(t.height)]);
    }
    for(const e of host.querySelectorAll('h2,button,label,p,span')){
     if(!visible(e)||e.children.length||!e.textContent.trim()||getComputedStyle(e).textOverflow==='ellipsis')continue;
     const range=document.createRange();range.selectNodeContents(e);
     for(const b of range.getClientRects())if(b.left<host.getBoundingClientRect().left-1||b.right>host.getBoundingClientRect().right+1)issues.push(['text outside panel',e.textContent.trim()]);
    }
    const cancel=host.querySelector('[aria-label="Cancel current tool"]');
    if(cancel){const r=document.createRange();r.selectNodeContents(cancel);if(r.getBoundingClientRect().height>parseFloat(getComputedStyle(cancel).lineHeight)*1.1)issues.push(['broken Cancel label']);}
    const action=host.querySelector('.air-editor-actions');
    if(action){const b=action.getBoundingClientRect();if(b.bottom>innerHeight+1||b.top<0)issues.push(['actions outside viewport']);}
    return {issues,panel:{x:bounds.x,y:bounds.y,width:bounds.width,height:bounds.height},scrollable:panel.scrollHeight>panel.clientHeight};
   });
   const row={engine,width,height,font,theme,name,...proof};results.push(row);
   for(const issue of proof.issues)failures.push({...row,issues:undefined,issue});
   if(proof.issues.length||([390,768,1440].includes(width)&&font===16))await p.screenshot({path:`${out}/${width}-${font}-${theme}-${name.toLowerCase().replace(/[^a-z]+/g,'-')}.png`});
  }
  console.log(JSON.stringify({engine,width,height,font,theme,tools:names.length,failures:failures.length}));
  await p.close();
 }
}finally{await writeFile(`${out}/results.json`,JSON.stringify({results,errors,failures},null,2)+'\n');await browser.close();}
assert.deepEqual(errors,[]);assert.deepEqual(failures,[]);
