import subprocess,json,os,time,concurrent.futures
from pathlib import Path
f=Path(os.environ['AIR_FAMILY_ROOT']);out=f/'evidence/cube-growth';out.mkdir(exist_ok=True);tasks=[]
def add(n,a,s,e=None):tasks.append((n,a,['node','--preserve-symlinks-main',str(f/a/'scripts'/s)],e or {}))
for n in ['family','privacy','dialogs','notices']:add(n,'cloakyard',f'test-air-{n}.mjs')
add('presence','cloakyard','test-air-presence.mjs',{'AIR_PROFILES':'[[390,844],[768,1024],[1280,720],[1440,900]]'})
for engine in ['chromium','webkit']:
 add('editors-'+engine,'cloakyard','test-air-editors.mjs',{'AIR_BROWSER':engine,'AIR_PROFILES':'[[390,844],[768,1024],[1280,720],[1440,900]]'})
 add('artwork-'+engine,'cloakyard','test-air-artwork-browsers.mjs',{'AIR_BROWSER':engine})
add('growth','cloakyard','test-air-growth.mjs',{'SITE_URL':'http://127.0.0.1:8820'})
add('img-tools','cloakimg','test-air-tool-states.mjs',{'AIR_BROWSER':'chromium','BASE_URL':'http://127.0.0.1:8822','AIR_PROFILES':'[[390,844,16],[768,1024,16],[1280,720,16],[1440,900,16]]'})
for n in ['entry','batch']:add('img-'+n,'cloakimg',f'test-air-{n}.mjs',{'BASE_URL':'http://127.0.0.1:8822'})
for n in ['sections','library','review','options','dates','logo-photo','contact-selects']:add('resume-'+n,'cloakresume',f'test-air-{n}.mjs',{'SITE_URL':'http://127.0.0.1:8823'})
for n in ['navigation','collections']:tasks.append(('pdf-'+n,'cloakpdf',['node','--experimental-strip-types',f'tests/e2e/editor-{n}.e2e.ts'],{'E2E_URL':'http://127.0.0.1:8821'}))
add('pdf-actions','cloakpdf','test-air-tool-actions.mjs',{'BASE_URL':'http://127.0.0.1:8821'})
tasks.append(('pdf-standalone','.', ['node','cube-pdf-standalone.mjs'],{}))
results=[]
def run(t):
 name,app,cmd,extra=t;env=os.environ|{'AIR_EVIDENCE_DIR':str(out/name)}|extra;start=time.time();(out/name).mkdir(exist_ok=True)
 with (out/(name+'.log')).open('w')as log:r=subprocess.run(cmd,cwd=f/app,env=env,stdout=log,stderr=subprocess.STDOUT)
 return {'name':name,'app':app,'command':cmd,'env':extra,'exitCode':r.returncode,'seconds':round(time.time()-start,2)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
 for future in concurrent.futures.as_completed([pool.submit(run,t)for t in tasks]):
  r=future.result();results.append(r);(out/'audit.json').write_text(json.dumps(results,indent=2)+'\n');print(r['name'],r['exitCode'],flush=True)
if any(r['exitCode']for r in results):raise SystemExit(1)
