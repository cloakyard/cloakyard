import {mkdir,writeFile} from 'node:fs/promises';
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE);const {default:sharp}=await import(process.env.SHARP_MODULE);
const b=await chromium.launch({executablePath:process.env.CHROME_PATH});const out='evidence/cube-growth/motion';await mkdir(out,{recursive:true});
for(const theme of ['light','dark']){
 const p=await b.newPage({viewport:{width:1440,height:900},colorScheme:theme});
 await p.addInitScript(()=>Object.defineProperty(navigator,'deviceMemory',{value:8}));await p.goto('http://127.0.0.1:8820');const art=p.locator('.yard-growth');await art.scrollIntoViewIfNeeded();await p.waitForFunction(()=>document.querySelector('.yard-growth')?.dataset.artState==='playing');
 await art.evaluate(el=>{window.previewEffects=el.getAnimations({subtree:true});window.previewEffects.forEach(a=>{a.pause();a.currentTime=0})});
 for(let frame=0;frame<96;frame++){
  const time=Math.min(frame*50,3740);await p.evaluate(async time=>{window.previewEffects.forEach(a=>a.currentTime=time);await new Promise(requestAnimationFrame)},time);
  await art.screenshot({path:`${out}/${theme}-${String(frame).padStart(3,'0')}.png`,animations:'allow'});
 }
 const frames=[0,10,23,36,49,62,70,80];const tiles=await Promise.all(frames.map(async(n)=>({input:await sharp(`${out}/${theme}-${String(n).padStart(3,'0')}.png`).resize(270,180).toBuffer()})));await sharp({create:{width:1080,height:360,channels:4,background:theme==='light'?'#fafbfc':'#101216'}}).composite(tiles.map((tile,i)=>({...tile,left:i%4*270,top:Math.floor(i/4)*180}))).webp().toFile(`${out}/${theme}-storyboard.webp`);await p.close();
}
await b.close();
