import re,json,subprocess
from pathlib import Path
f=Path(__file__).parent;rows=[]
for app in ['cloakyard','cloakpdf','cloakimg','cloakresume','cloakdrop','cloakroll']:
 root=f/app
 files=[root/p for p in subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()]
 tokens=set()
 for p in files:
  if p.suffix in ['.tsx','.ts','.jsx','.js','.html','.astro','.mjs','.json'] and ('src' in p.parts or p.parent==root) and p.stat().st_size<1_000_000:
   tokens.update(re.findall(r'[a-zA-Z_][\w-]*',p.read_text(errors='replace')))
 for css in files:
  if css.suffix!='.css' or not ('src' in css.parts or css.name=='tokens.css') or css.name=='air.css' or '/docs/air/' in str(css): continue
  text=re.sub(r'/\*[\s\S]*?\*/','',css.read_text())
  candidates=sorted(set(re.findall(r'(?<![\d\w-])\.([a-zA-Z_][\w-]*)',text))-tokens)
  rows.append({'file':str(css.relative_to(f)),'unmatchedCandidates':candidates})
(f/'evidence/refinement/css-review.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps([r for r in rows if r['unmatchedCandidates']],indent=2))
