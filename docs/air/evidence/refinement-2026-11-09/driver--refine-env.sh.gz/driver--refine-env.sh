source /Users/sumitsahoo/Developer/.air-mobile-2026-11-09/audit-env.sh
export AIR_FAMILY_URLS=http://127.0.0.1:8820,http://127.0.0.1:8821,http://127.0.0.1:8824,http://127.0.0.1:8823,http://127.0.0.1:8825,http://127.0.0.1:8822
export AIR_EDITOR_URLS=http://127.0.0.1:8821,http://127.0.0.1:8822,http://127.0.0.1:8823
export AIR_PDF_FIXTURE="$AIR_FAMILY_ROOT/evidence/live-sample.pdf"
export AIR_PRIVACY_URLS="$AIR_FAMILY_URLS"
export AIR_DIALOG_URLS="$AIR_EDITOR_URLS"
unset NODE_OPTIONS
