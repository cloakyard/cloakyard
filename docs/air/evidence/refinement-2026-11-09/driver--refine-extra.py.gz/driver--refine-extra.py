import subprocess,json,os,time
from pathlib import Path
f=Path(os.environ['AIR_FAMILY_ROOT']);out=f/'evidence/refinement';results=[]
tasks=[('public-tablet','.', ['node','refine-public-capture.mjs'],{}),('pdf-standalone','.', ['node','refine-pdf-standalone.mjs'],{}),('pdf-navigation','cloakpdf',['node','--experimental-strip-types','tests/e2e/editor-navigation.e2e.ts'],{'E2E_URL':'http://127.0.0.1:8821'}),('pdf-collections','cloakpdf',['node','--experimental-strip-types','tests/e2e/editor-collections.e2e.ts'],{'E2E_URL':'http://127.0.0.1:8821'}),('img-output','cloakimg',['node','scripts/test-air-touch-output.mjs'],{'BASE_URL':'http://127.0.0.1:8822'})]
for name,cwd,cmd,extra in tasks[1:]:
 env=os.environ|{'AIR_EVIDENCE_DIR':str(out/name)}|extra;start=time.time()
 (out/name).mkdir(exist_ok=True)
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=f/cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,cwd=cwd,command=cmd,env=extra,exitCode=r.returncode,seconds=round(time.time()-start,2)))
 (out/'ui-extra-rerun.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
