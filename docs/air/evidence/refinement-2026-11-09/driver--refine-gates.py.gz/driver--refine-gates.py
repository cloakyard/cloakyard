import subprocess, json, os, time
from pathlib import Path
f=Path(os.environ['AIR_FAMILY_ROOT']); out=f/'evidence/refinement'; results=[]
tasks=[]
for app in ['cloakyard','cloakpdf','cloakimg','cloakresume']:
 tasks.append((app+'-check',app,'vp check --fix'))
 tasks.append((app+'-build',app,'vp run build'))
 tasks.append((app+'-dead',app,'pnpm check:dead' if app=='cloakpdf' else 'npx --yes knip@6.44.2'))
 if app=='cloakyard':
  tasks.extend([('yard-types',app,'pnpm exec tsc --noEmit'),('yard-tests',app,'node --test scripts/test-air-file-workflow.mjs scripts/test-air-reference-safety.mjs')])
 elif app=='cloakresume': tasks.append((app+'-tests',app,'CLOAKRESUME_BROWSER_BUILD=production vp test run --no-file-parallelism'))
 else: tasks.append((app+'-tests',app,'vp test run tests/unit' if app=='cloakpdf' else 'vp test run'))
 tasks.append((app+'-design',app,'node scripts/check-air-design.mjs && node scripts/check-air-portability.mjs'))
for app in ['cloakdrop','cloakroll']:
 tasks.append((app+'-build',app+'/apps/site','npm run verify && npm run check:worker' if app=='cloakroll' else 'npm run check && npm run build && npx wrangler deploy --dry-run'))
 tasks.append((app+'-dead',app+'/apps/site','npx --yes knip@6.44.2'))
 tasks.append((app+'-design',app,'node scripts/check-air-design.mjs && node scripts/check-air-portability.mjs'))
tasks.append(('family-portability','cloakyard',f'node --preserve-symlinks-main {f}/cloakyard/scripts/sync-air-design.mjs --bundle --check'))
tasks.append(('readmes','cloakyard',f'node scripts/check-readmes.mjs --family {f}'))
for name,cwd,cmd in tasks:
 start=time.time()
 with (out/(name+'.log')).open('w') as log: r=subprocess.run(['zsh','-c',cmd],cwd=f/cwd,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,cwd=cwd,exitCode=r.returncode,seconds=round(time.time()-start,2)))
 (out/'gates.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode: raise SystemExit(r.returncode)
