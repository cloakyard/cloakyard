import subprocess,json,sys
from pathlib import Path
out=Path('evidence/refinement/live');out.mkdir(parents=True,exist_ok=True)
for app in sys.argv[1:]:
 def api(path):return json.loads(subprocess.check_output(['gh','api',path]))
 sha=api(f'repos/cloakyard/{app}/git/ref/heads/main')['object']['sha']
 status=api(f'repos/cloakyard/{app}/commits/{sha}/status')
 checks=api(f'repos/cloakyard/{app}/commits/{sha}/check-runs')['check_runs']
 result={'app':app,'main':sha,'combinedState':status['state'],'statuses':[{'name':s['context'],'state':s['state'],'url':s['target_url']}for s in status['statuses']],'checks':[{'name':s['name'],'status':s['status'],'conclusion':s['conclusion'],'url':s['html_url']}for s in checks]}
 result['pass']=any('Workers Builds:' in s['name'] for s in result['statuses']+result['checks']) and bool(result['statuses'] or result['checks']) and all(s['state']=='success' for s in result['statuses']) and all(s['conclusion'] in ['success','skipped'] for s in result['checks'])
 (out/(app+'-main.json')).write_text(json.dumps(result,indent=2)+'\n');print(app,sha,result['pass'],[(s['name'],s['state'])for s in result['statuses']],[(s['name'],s['conclusion'])for s in result['checks']])
