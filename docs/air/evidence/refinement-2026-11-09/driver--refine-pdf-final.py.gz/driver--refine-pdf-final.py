import subprocess,os,json,time
from pathlib import Path
f=Path(os.environ['AIR_FAMILY_ROOT']);out=f/'evidence/refinement';results=[]
tasks=[('pdf-final-check','cloakpdf',['vp','check']),('pdf-final-unit','cloakpdf',['vp','run','test:unit']),('pdf-final-build','cloakpdf',['vp','run','build']),('pdf-standalone-feature','cloakpdf',['node','--experimental-strip-types','tests/e2e/standalone-tools.e2e.ts']),('pdf-standalone-final','.', ['node','refine-pdf-standalone.mjs']),('public-final','.', ['node','refine-public-capture.mjs']),('pdf-final-shots','cloakpdf',['node','scripts/build-app-screenshots.mjs']),('pdf-final-og','cloakpdf',['node','scripts/build-og-image.mjs']),('pdf-final-assets','cloakpdf',['vp','run','build'])]
for name,app,cmd in tasks:
 env=os.environ|{'E2E_URL':'http://127.0.0.1:8821','BASE_URL':'http://127.0.0.1:8821','SITE_URL':'http://127.0.0.1:8821','AIR_EVIDENCE_DIR':str(out/name)}
 (out/name).mkdir(exist_ok=True);start=time.time()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=f/app,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exitCode=r.returncode,seconds=round(time.time()-start,2)))
 (out/'pdf-final.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
