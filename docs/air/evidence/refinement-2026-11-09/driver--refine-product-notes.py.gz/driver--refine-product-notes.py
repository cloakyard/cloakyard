from pathlib import Path
import json,gzip,hashlib
f=Path('.');e=f/'evidence/refinement'
notes={
'cloakpdf':('CloakPDF', '''Standalone tool/category headings, password recovery and download actions now
follow Air sentence case. Routes and output behavior are unchanged. README and
PWA/editor/social captures use the current UI and shared family structure.

Lint/types/build/asset limits, Knip, Air integrity/portability and 461 unit tests
pass. Six standalone workflows verify real downloads, encryption, extraction,
comparison and independently verified digital signatures. Chromium/WebKit pass
260 standalone states plus 20 fully loaded Ask entry states. Fresh navigation
covers 148 layouts and 176 tool selections; collections cover 88 layouts and
real downloads; all 16 phone transaction/output journeys pass. AI-dialog recovery,
loading and deletion checks cover 192 theme/viewport/text cases without a new
inference run. The existing approved Compact quality limitation is unchanged.
''', ['pdf-final.json','pdf-final-rerun.json','pdf-copy-final.json','pdf-standalone/results.json','pdf-ask-ready/results.json','pdf-copy-feature.log','pdf-ai-states.log','pdf-actions.log']),
'cloakimg':('CloakIMG','''Six unused compatibility CSS selectors and redundant Knip entries are removed.
Live dynamic selectors, shared portable Air controls, image processing and output
styles are preserved. Capture automation now uses actual UI controls and isolated
contexts, producing both themes. Dark documentation images stay outside the PWA
precache. Focus/batch regressions wait for the actual intended surface.

Lint/types/build, Knip, Air integrity/portability and 488 unit tests pass. All 26
tools and alternate states pass 840 observations per engine (Chromium/WebKit),
including phone/tablet/laptop/desktop, both themes and enlarged text. Entry passes
204 layouts and fidelity checks; batch passes 176 observations. Twenty canvas
journeys and eight completion journeys pass. Twelve actual exported PNGs match
the baseline decoded pixels exactly. No processing or output feature was removed.
''', ['img-final-check.log','img-final-build.log','img-tools-chromium/results.json','img-tools-webkit/results.json','img-entry/entry.json','img-batch/results.json','img-canvas/results.json','img-compact/results.json','img-output-parity.json'])}
for app,(name,body,receipts) in notes.items():
 p=f/app/'docs/air/refinement-2026-11-09.md'
 p.write_text(f'''# {name} refinement — 2026-11-09

Air remains 1.7.1. {body}
The six-product comparison includes public pages, workspace/tool interiors,
secondary flows, policy/recovery, dialogs, update notices and motion. Both browser
engines pass 66 cross-editor cases each; 264 dialog cases, 396 notice states and
230 presence/workflow cases pass. Rendered phone, tablet, laptop and desktop
captures were visually reviewed in both themes. The family README checker
validates eight documents and 114 local references.

See the canonical [per-view ledger](https://github.com/cloakyard/cloakyard/blob/dev/docs/air/refinement-2026-11-09.md)
for detailed coverage and diagnostics. Compressed receipts are retained locally in
`evidence/refinement-2026-11-09/`. Initial test-harness failures are preserved in the
family evidence; passing reruns determine acceptance. Original unrelated PDF AI
work and native products remain untouched. Physical-device, OS input/IME,
actual browser zoom, spoken-assistive and physical-print acceptance remain open.
''')
 v=f/app/'docs/air/validation.md';s=v.read_text();i=s.find('\n')+1
 v.write_text(s[:i]+'\n## 2026-11-09 — Refinement, cleanup and README consistency\n\nSee [the refinement record](refinement-2026-11-09.md) for fresh all-view browser,\nsource and output evidence. Required software checks pass; physical-device and\nseparate product acceptance remain open.\n'+s[i:])
 dest=f/app/'docs/air/evidence/refinement-2026-11-09';dest.mkdir(parents=True,exist_ok=True);manifest=[]
 for item in ['gates.json','ui-shared.json','css-review.json']+receipts:
  b=(e/item).read_bytes();fn=item.replace('/','--')+'.gz';(dest/fn).write_bytes(gzip.compress(b));manifest.append({'source':item,'file':fn,'sha256':hashlib.sha256(b).hexdigest()})
 (dest/'manifest.json').write_text(json.dumps({'date':'2026-11-09','scope':'See local refinement record and canonical per-view ledger for limits.','receipts':manifest},indent=2)+'\n')
 inv=f/app/'docs/air/surfaces.json';d=json.loads(inv.read_text())
 for s in d['surfaces']:
  if s['path'] in (['src/tokens.css'] if app=='cloakimg' else ['src/components/EncryptedPdfNotice.tsx','src/standalone/MergePdf.tsx','src/standalone/ImagesToPdf.tsx','src/standalone/PdfPassword.tsx','src/standalone/DigitalSignature.tsx']):
   s.setdefault('evidence',[]).append('docs/air/refinement-2026-11-09.md')
   s['notes']+=' 2026-11-09: bounded cleanup/copy refinement and fresh responsive/browser/output verification pass; physical acceptance remains separate.'
 inv.write_text(json.dumps(d,indent=2)+'\n')
