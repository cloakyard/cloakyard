import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {spawnSync} from 'node:child_process';
const dir=await mkdtemp(join(tmpdir(),'air-readme-check-'));
const apps=['cloakyard','cloakpdf','cloakimg','cloakresume','cloakdrop','cloakroll'];
const sections=['Overview','Features','Privacy','Getting started','Development','Design and assets','Project structure','Deployment and releases','Contributing','License'];
const fixture='# Product\n\n'+sections.map(s=>`## ${s}\n\nUseful content.\n`).join('\n');
const command=['cloakyard/scripts/check-readmes.mjs','--family',dir];
const receipts=[];
try {
 for(const app of apps){await mkdir(join(dir,app,'apps/site'),{recursive:true});for(const file of ['README.md',...(['cloakdrop','cloakroll'].includes(app)?['apps/site/README.md']:[])])await writeFile(join(dir,app,file),fixture);}
 const target=join(dir,'cloakimg/README.md');
 for(const [name,content,expected] of [
  ['valid-code-fence',fixture+'\n```md\n## Not a section\n[Not a link](missing)\n```\n',0],
  ['missing-section',fixture.replace('## Privacy','### Privacy'),1],
  ['dangling-file',fixture+'\n[Missing](does-not-exist.md)\n',1],
  ['dangling-anchor',fixture+'\n[Missing](#missing)\n',1],
  ['explicit-anchor',fixture+'\n<a id="old-section"></a>\n[Legacy](#old-section)\n',0],
 ]){await writeFile(target,content);const r=spawnSync('node',command,{encoding:'utf8'});assert.equal(r.status,expected,name);receipts.push({name,exitCode:r.status,expected});}
 await writeFile('evidence/refinement/readme-negative-checks.json',JSON.stringify(receipts,null,2)+'\n');console.log('5 README checker cases passed');
}finally{await rm(dir,{recursive:true,force:true});}
