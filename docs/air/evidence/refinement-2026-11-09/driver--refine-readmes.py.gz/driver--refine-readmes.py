from pathlib import Path
import re
apps=['cloakyard','cloakpdf','cloakimg','cloakresume','cloakdrop','cloakroll']
heads=['Overview','Features','Privacy','Getting started','Development','Design and assets','Project structure','Deployment and releases','Contributing','License']
names=dict(zip(apps,['Cloakyard','CloakPDF','CloakIMG','CloakResume','CloakDrop','CloakRoll']))
urls=dict(zip(apps,['https://cloakyard.com/','https://pdf.cloakyard.com/','https://img.cloakyard.com/','https://resume.cloakyard.com/','https://drop.cloakyard.com/','https://roll.cloakyard.com/']))
taglines=['Your work. A little lighter.','Your documents. On your device.','Your photos. Your way.','Your next chapter. In your words.','Downloads, thoughtfully managed.','Your camera roll, safely on your Mac.']
old={};sections={}
for a in apps:
 s=(Path(a)/'README.md').read_text();old[a]=s
 Path('evidence/refinement/'+a+'-README-before.md').write_text(s)
 matches=list(re.finditer(r'^## (.+)$',s,re.M));b={}
 for i,m in enumerate(matches):
  key=re.sub(r'^[^A-Za-z]+','',m[1]).strip();body=s[m.end():matches[i+1].start() if i+1<len(matches) else len(s)].strip();body=re.sub(r'\n---\s*$','',body).strip();b[key]=body
 sections[a]=b

def maptext(a):
 b=sections[a]
 if a in ['cloakdrop','cloakroll']:
  return b['Repository layout']
 if a=='cloakyard':return b['🗂️ Structure'] if '🗂️ Structure' in b else b['Structure']
 if a=='cloakresume':return b['Project map'].replace('│   ├── cloak-family.css       # Remaining compatibility adapters; see cleanup record','│   ├── cloak-family.css       # Live compatibility adapters').replace('│   └── index.css              # Base styles and Tailwind theme bridge','│   └── index.css              # Base styles and Tailwind theme bridge')
 if a=='cloakpdf':return '''```text
cloakpdf/
├── src/editor/             # Document workspace, rail and editing tools
├── src/standalone/         # Multi-file, security and Ask PDF workflows
├── src/components/         # Shared application controls and overlays
├── src/styles/             # Pinned Air foundations and product composition
├── public/                 # Local assets, PWA icons and real editor captures
├── scripts/                # Asset generation and browser/design checks
├── tests/                  # Unit, browser and output checks
├── docs/                   # Architecture, privacy, design and validation records
└── wrangler.jsonc          # Cloudflare static Worker configuration
```'''
 return '''```text
cloakimg/
├── src/editor/             # Canvas, tools, history, exports and on-device AI
├── src/components/         # Shared controls and overlays
├── src/landing/            # Public pages and finite landscape artwork
├── src/styles/             # Pinned Air foundations and page shells
├── public/                 # Local assets, codecs, models and PWA previews
├── scripts/                # Asset generation and browser/design checks
├── docs/                   # Architecture and verification records
└── wrangler.jsonc          # Cloudflare static Worker configuration
```'''

for i,a in enumerate(apps):
 b=sections[a];name=names[a];native=a in ['cloakdrop','cloakroll']
 overview={
 'cloakyard':'The directory for CloakPDF, CloakResume, CloakIMG, CloakDrop and CloakRoll, with a separate link to KERR. Web tools process work locally; the native apps have their own documented network and storage boundaries.',
 'cloakpdf':'A private PDF editor and toolkit that processes documents in your browser. Open a PDF to edit, annotate, redact and export it, or choose a standalone workflow for multiple files, security or on-device questions.',
 'cloakimg':'A private browser photo editor with local retouching, annotation, metadata removal and optional on-device AI. Keep the photo visible while working, then export the result in the format you need.',
 'cloakresume':'Build, tailor, review and export a résumé in your browser. The application keeps document content local while supporting multiple layouts, portable files and writing review.',
 'cloakdrop':'An open-source download manager for Apple silicon Macs, with parallel transfers, saved progress and video capture. The native SwiftUI app and independently tested Swift engine are separate from the Air website.',
 'cloakroll':'A native macOS app for backing up iPhone photos and videos over USB. Browse the library and copy original components into folders you control. The SwiftUI app is separate from the Air website.'}[a]
 blocks={h:'' for h in heads};blocks['Overview']=overview
 if a=='cloakyard':
  blocks['Features']=b['The yard'].replace('### 🛠️ Productivity','### Productivity').replace('### 🧪 Fun experiments','### Explorations')
  blocks['Features']+='\n\n### Family artwork\n\n'+b['Contributing and license'].split('### Family gathering\n\n')[1]
  blocks['Privacy']='The directory has no accounts, analytics or runtime data API. Browsers request static website assets; each linked app owns its own processing, storage and privacy policy. Read the [website policy](https://cloakyard.com/?view=privacy).\n\n'+b['Principles'].replace('The site makes no API calls, has no account layer, and ships no analytics.','')
  blocks['Getting started']='Open [cloakyard.com](https://cloakyard.com/) and choose an app. Browser tools open directly; native products link to their websites and published downloads.'
  dev=b['Getting started'].replace('`vp check`      | Format, lint, and type-check','`vp check`      | Format and lint').replace('curl -fsSL https://vite.plus | bash','npm install --global vite-plus')
  blocks['Development']=dev+'\n\nAlso run `vp exec tsc --noEmit`, `node scripts/check-air-design.mjs` and `npx --yes knip@6.44.2`.\n\n### Technology\n\n'+b['Tech stack']
  blocks['Design and assets']='This repository owns the [portable Air contract](design/air/contract.md), [reference and tokens](design/air/README.md), and [component matrix](design/air/COMPONENTS.md). The current pinned baseline is Air 1.7.1. Product copies are generated with `node scripts/sync-air-design.mjs --bundle`; verify them with `--bundle --check`.\n\nRead [DESIGN.md](DESIGN.md) before UI changes. The [refresh ledger](UX_REFRESH_TODO.md) and [handoff](docs/air/RESUME.md) distinguish verified software coverage from open physical-device acceptance. [README guidance](docs/README_STANDARD.md) defines the family documentation structure. `artwork/og.html` and `vp run generate:og` own the local social preview.'
  blocks['Deployment and releases']=b['Deploying to Cloudflare Workers'].replace('pushes to the production branch publish the Worker.','only approved main-branch changes publish the production Worker.')+'\n\nPromote tested work through a `dev` → `main` PR, then update `dev` from `main`. Verify the exact main build and live assets after deployment.'
 elif not native:
  if a=='cloakpdf':
   blocks['Features']=b['What it does']+'\n\n### On-device AI\n\n'+b['On-device AI']
   blocks['Privacy']=b['Privacy first']
   dev=b['Getting started'].replace('vp install   # needs Node ≥ 24 and `npm i -g vite-plus`','vp install').replace('| `vp build`                  | Type-check + production build','| `vp run build`              | Type-check, build and verify deployment assets')
   dev='Requires Node.js 24 or newer and the Vite+ CLI (`npm install --global vite-plus`).\n\n'+dev
   blocks['Design and assets']='[DESIGN.md](DESIGN.md) is the portable Air contract. [Surface coverage](docs/air/surfaces.json) and [validation](docs/air/validation.md) record actual states and remaining acceptance. UI changes use the pinned local Air bundle; document output retains its chosen appearance.\n\n'+b['Brand assets']
   test='Run `vp check`, `pnpm check:dead`, `vp test run tests/unit` and `vp run build` before committing. Run the applicable browser suites from [CLAUDE.md](CLAUDE.md) against a production preview. AI inference checks are separate from deterministic dialog-state checks.'
  elif a=='cloakimg':
   blocks['Features']=b['Features'].replace('### 🧠 On-device AI','### On-device AI').replace('### 🧭 Workspace & export','### Workspace and export').replace('focused phone controls with a persistent tool dock','focused phone controls with a tool picker').replace('Undo, redo and export stay in the canvas toolbar.','Undo, redo and export stay beside the canvas; additional actions live in More actions on compact layouts.')
   blocks['Privacy']=b['Privacy'].replace('a strict CSP blocks any outbound request for image data.','editing and export run locally; there is no image-upload endpoint.').replace('every byte stays on your device','photos and edits stay on your device')
   dev=b['Getting Started']
   blocks['Design and assets']='[DESIGN.md](DESIGN.md) is the portable Air contract; [surface coverage](docs/air/surfaces.json) records actual verification. Shared controls remain neutral in both themes. The finite sun-and-mountains artwork has its own product colour; authored image pixels are not UI colours.\n\n### Editor previews\n\nThe README and PWA previews are real captures using the bundled local orange photograph. Run a production preview, then `BASE_URL=http://127.0.0.1:4173 vp run generate-screenshots` to capture phone and tablet layouts in light and dark. `node scripts/build-og-image.mjs` renders the separate vector social card.'
   test='Run `vp check`, `vp test run`, `npx --yes knip@6.44.2` and `vp run build`. Use the applicable tool, transaction, output and browser suites under `scripts/`; models must remain behind explicit consent. Browser tooling is development-only.'
  else:
   blocks['Features']=b['What it does']+'\n\n### Portable files\n\n'+b['Portable files']
   blocks['Privacy']=b['Privacy and offline behavior']
   dev=b['Getting started'].replace('| `vp build`','| `vp run build`')
   blocks['Design and assets']=b['Design and asset references']
   test='Run `vp check`, `npx --yes knip@6.44.2`, `vp run build` and the production browser/test command above. A missing browser or skipped required test is not a passing gate. Preserve template typography, pagination, selectable text and links.'
  blocks['Getting started']=f'Open [{urls[a].split("//")[1].rstrip("/")}]({urls[a]}) in a modern browser. '+{'cloakpdf':'Drop a PDF or browse for one, choose a tool, then export. Standalone cards handle multi-file jobs.','cloakimg':'Drop, paste or browse for a photo. Choose a tool; Apply keeps its staged edit and Cancel restores the starting state. Export when ready.','cloakresume':'Start blank, use a sample, import an editable file or restore a saved draft. Choose a section to edit, then export or save a portable copy.'}[a]+'\n\nThe installable PWA caches its core shell after loading. Optional language/model assets require their own initial download; cached availability depends on browser storage.'
  blocks['Development']=dev+'\n\n### Verification\n\n'+test+'\n\n### Technology\n\n'+b.get('Tech stack',b.get('Tech Stack',b.get('Technology','')))
  blocks['Deployment and releases']='The production build is served as static assets by Cloudflare Workers using `wrangler.jsonc`. Run `vp run build` before `vp preview` or a deployment dry run. Work on `dev`, open a PR into `main`, merge only after required checks pass, and update `dev` from `main`.\n\nOnly the configured main-branch deployment publishes production. Check the exact main commit, hosting result and live assets; a local build does not prove deployment. Native output files are never uploaded as part of publishing the website.'
 else:
  blocks['Features']=b['What it does']+'\n\n### Troubleshooting\n\n'+re.sub(r'^### ', '#### ', b['Troubleshooting'],flags=re.M)
  blocks['Privacy']=b['Privacy']
  version='Version 1.0.0' if a=='cloakdrop' else 'Version 0.1.0 beta'
  blocks['Getting started']=b['Download and install']+'\n\n### Published release and source\n\n'+b[version]
  blocks['Development']='### Native app\n\n'+b['Build the app']+'\n\n### Verification\n\n'+b['Testing']+'\n\n### Website\n\nThe independent Air website is in [`apps/site`](apps/site/README.md). Its README documents Node/npm setup, browser verification and deployment; native tests do not verify website layouts.'
  blocks['Design and assets']='The website follows the portable [Air contract](DESIGN.md) and its pinned local bundle. The native app keeps SwiftUI, SF Symbols and macOS system conventions. Do not apply web control skins to native UI.\n\n[Brand assets](assets/README.md) own the marks, installer artwork and synthetic screenshots. Website asset sync reads those checked-in sources; edit the sources rather than generated copies. Screenshots are examples, not evidence of a real transfer or backup.'
  blocks['Deployment and releases']='Publish website changes through tested `dev` → `main` PRs and keep `dev` updated. When dev also holds unrelated native work, use a separately reviewed website-only PR under the maintainer\'s approved exception, then merge main into dev without releasing that native work. The [website guide](apps/site/README.md#deployment-and-releases) records build and deployment commands.\n\nNative release preparation is separate from website deployment. Follow the existing build/packaging and verification instructions above; publish binaries and checksums to [GitHub Releases](https://github.com/cloakyard/'+a+'/releases), not the source tree. Preserve documented signing, runtime and physical-device limits.'
 blocks['Project structure']=maptext(a)
 blocks['Contributing']='Read [AGENTS.md](AGENTS.md), [CLAUDE.md](CLAUDE.md) and [DESIGN.md](DESIGN.md) before changes. '+('See [CONTRIBUTING.md](CONTRIBUTING.md) for contribution and disclosure guidance. ' if (Path(a)/'CONTRIBUTING.md').exists() else '')+'Keep changes bounded, preserve features and output, remove obsolete references, and record actual verification. Compare all applicable views in phone, tablet, laptop and desktop layouts, both themes.\n\nThe [family README standard](https://github.com/cloakyard/cloakyard/blob/main/docs/README_STANDARD.md) defines this document\'s section order. Support the project through [Buy me a coffee](https://ko-fi.com/sumitsahoo21).'
 blocks['License']='Released under the [MIT License](LICENSE). Third-party components retain their own licenses.\n\nBuilt by [Sumit Sahoo](https://github.com/sumitsahoo), part of [Cloakyard](https://cloakyard.com/).'
 # Keep existing status badges and real product imagery, in one consistent header order.
 intro=old[a].split('\n## ')[0]
 ps=re.findall(r'<p(?:\s[^>]*)?>.*?</p>',intro,re.S)
 badge=next((p for p in ps if 'shields.io' in p),'')
 picture=next((p for p in ps if '<img' in p and 'shields.io' not in p),'')
 if a=='cloakimg':picture='''<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="public/screenshots/iPad-dark.png">
    <img src="public/screenshots/iPad.png" alt="CloakIMG Air tablet editor with a local photo and Adjust controls" width="800">
  </picture>
</p>'''
 picture=picture.replace('width="900"','width="800"')
 header=f'# {name}\n\n**{taglines[i]}**\n\n[Website]({urls[a]}) · [Source](https://github.com/cloakyard/{a}) · [Support](https://ko-fi.com/sumitsahoo21)\n\n'+badge+'\n\n'+picture+'\n\n'
 (Path(a)/'README.md').write_text(header+'\n\n'.join('## '+h+'\n\n'+blocks[h].strip() for h in heads)+'\n')
