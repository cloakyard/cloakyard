from pathlib import Path
import subprocess,os,json,time
f=Path(os.environ['AIR_FAMILY_ROOT']);out=f/'evidence/refinement'
while True:
 try:os.kill(76598,0);time.sleep(1)
 except ProcessLookupError:break
r=json.loads((out/'ui-tools-rerun.json').read_text());assert len(r)==8 and all(x['exitCode']==0 for x in r),r
s=(f/'cloakresume/scripts/test-air-sections.mjs').read_text().replace('from "puppeteer-core"','from "'+str(f/'cloakresume/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js')+'"').replace('from "../src/data/blankResume.ts"','from "'+str(f/'cloakresume/src/data/blankResume.ts')+'"')
s=s.replace('(text === 16 &&\n                ((w === 1440 && theme === "light") || (w === 390 && theme === "dark")))','(text === 16 && [390,768,1280,1440].includes(w))')
(f/'refine-resume-copy-states.mjs').write_text(s)
tasks=[('resume-copy-check',['vp','check']),('resume-copy-build',['vp','run','build']),('resume-copy-feature',['vp','test','run','tests/editor-browser.spec.ts','-t','preserves comma entry']),('resume-copy-states',['node',str(f/'refine-resume-copy-states.mjs')])];results=[]
for name,cmd in tasks:
 env=os.environ|{'CLOAKRESUME_BROWSER_BUILD':'production','SITE_URL':'http://127.0.0.1:8823','AIR_SECTION':'Interests & tools','AIR_EVIDENCE_DIR':str(out/name)};start=time.time()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=f/'cloakresume',env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exitCode':p.returncode,'seconds':round(time.time()-start,2)});(out/'resume-copy-final.json').write_text(json.dumps(results,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
