import assert from 'node:assert/strict';import{readFile,writeFile}from'node:fs/promises';import{createHash}from'node:crypto';
const hash=b=>createHash('sha256').update(b).digest('hex');const rows=[];
for(const file of ['index.html','404.html','privacy/index.html']){
const path=file.replace(/(^|\/)index\.html$/,'$1');const response=await fetch(`https://roll.cloakyard.com/${path}?air-audit=20261109refinement-normalized`);assert.equal(response.status,200);const actual=await response.text(),expected=await readFile(`cloakroll/apps/site/dist/${file}`,'utf8');
const scripts=[...actual.matchAll(/<script>\(function\(\)\{function c\(\)\{[\s\S]*?<\/script>/g)].filter(x=>x[0].includes('/cdn-cgi/challenge-platform/scripts/jsd/main.js')&&x[0].includes('window.__CF$cv$params'));
assert.equal(scripts.length,1);const normalized=actual.replace(scripts[0][0],'');assert.equal(normalized,expected);rows.push({file,status:response.status,expected:hash(expected),normalized:hash(normalized),injection:hash(scripts[0][0]),match:true});
}
await writeFile('evidence/refinement/live/roll-normalized.json',JSON.stringify({scope:'Only the identified existing Cloudflare challenge script is removed; all remaining bytes match.',rows},null,2)+'\n');console.log('3 Roll HTML files match after identified challenge injection removal');
