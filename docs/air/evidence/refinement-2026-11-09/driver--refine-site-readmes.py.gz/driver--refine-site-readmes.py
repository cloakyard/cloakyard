from pathlib import Path
import re
heads=['Overview','Features','Privacy','Getting started','Development','Design and assets','Project structure','Deployment and releases','Contributing','License']
for app in ['cloakdrop','cloakroll']:
 name='CloakDrop' if app=='cloakdrop' else 'CloakRoll';p=Path(app)/'apps/site/README.md';old=p.read_text();Path('evidence/refinement/'+app+'-site-README-before.md').write_text(old)
 sections={};matches=list(re.finditer(r'^## (.+)$',old,re.M))
 for i,m in enumerate(matches):sections[m[1]]=old[m.end():matches[i+1].start() if i+1<len(matches) else len(old)].strip()
 url='https://'+('drop' if app=='cloakdrop' else 'roll')+'.cloakyard.com/'
 b={};b['Overview']=f'The static Astro website for [{name}]({url}), hosted as a Cloudflare Worker. The native macOS app lives separately in [`../macos`](../macos); this directory owns the landing, privacy and recovery pages.'
 b['Features']='A finite product illustration, clear download/installation guidance, real native-app screenshots and the shared Air header/footer. Navigation and policy reading remain useful without JavaScript. The small local script adds Escape, anchor focus and active-section behavior.\n\n'+('Teal square pixels form FILE, PKG, ISO and ZIP once, then rest.','A local filmstrip arrives once, then rests.')[app=='cloakroll']+' The shared lifecycle pauses offscreen/hidden and respects reduced motion, forced colours, Save-Data and constrained devices. After completion, the artwork itself accepts a deliberate replay; there are no separate playback controls.'
 b['Privacy']='The site serves static assets without analytics, external fonts, a database or media uploads. Cloudflare handles website requests. Native-app processing and network behavior are described separately in the '+('[root privacy policy](../../PRIVACY.md)' if app=='cloakdrop' else '[native privacy policy](../../docs/PRIVACY.md)')+'; the website preserves that policy and its genuine revision date. Keep policy sources and displayed copy aligned.'
 b['Getting started']=f'Visit [{url.split("//")[1].rstrip("/")}]({url}) for the product and published downloads. The website links to the [GitHub Releases index](https://github.com/cloakyard/{app}/releases) so prereleases remain visible. Source versions, available releases and signing status are distinct; preserve the current [root installation guidance](../../README.md#getting-started).'
 b['Development']='''Use the Node range in `package.json` (`^22.23.4 || ^24.15.0 || >=26.0.0`) and the pinned npm 12.2.2. From a full repository checkout:

```sh
cd apps/site
npx --yes npm@12.2.2 ci
npm run dev
```

| Command | Purpose |
| --- | --- |
| `npm run check` | Astro type checking |
| `npm run build` | Sync source assets and build static `dist/` |
| `npm run preview` | Serve the production build |
| `npm audit` | Check the dependency graph |
| `npx --yes knip@6.44.2` | Audit the web module/dependency graph |

TypeScript 6 is retained for the supported Astro checker. Astro 7 may leave a server running after the command returns; stop owned servers with `npx astro dev stop` or `npx astro preview stop`.
'''
 if app=='cloakdrop':b['Development']+='\n### Browser verification\n\n'+sections['Air browser acceptance'].replace('8144','8824')
 else:b['Development']+='\n`npm run verify` combines type checking, build and route/asset/canonical-source checks. `npm run check:worker` dry-runs the Worker without publishing. Run both before committing. Website checks do not certify native or physical-device acceptance.\n\nInspect phone, tablet, laptop and desktop in both themes, including privacy/recovery, menu focus, enlarged text, reduced motion and no-JavaScript fallback.'
 b['Design and assets']='Read the complete portable [DESIGN.md](DESIGN.md) before visible changes. The pinned `src/styles/air.css` owns shared tokens, controls and page geometry; `src/styles/global.css` owns product composition. Product colours stay in artwork.\n\n'+('The root `scripts/sync-assets.mjs` copies marks, icons, native screenshots and the OG card from [`../../assets`](../../assets). Edit those sources, then run `npm run sync:assets` or rebuild.','`scripts/sync-assets.mjs` copies the native app icon and synthetic library screenshots from the repository sources. Do not use a site-only sparse checkout. Edit source assets, then rebuild.')[app=='cloakroll']+' Generated public copies are not the source of truth. Screenshot content is illustrative; it contains no personal media.\n\nThe [surface inventory](../../docs/air/surfaces.json) and dated audits record actual verification separately from the design reference.'
 if app=='cloakdrop':
  structure=sections['Structure'].split('\n\nEdit shared')[0];b['Project structure']=structure+'\n\nProduct copy and links live in [`src/data/site.ts`](src/data/site.ts). The [root documentation](../../docs/README.md) links release and verification records.'
 else:b['Project structure']='''```text
apps/site/
├── src/components/       # Landing sections, public chrome and artwork
├── src/pages/            # Home, privacy and recovery routes
├── src/styles/           # Pinned Air foundation and site composition
├── scripts/              # Asset sync and static verification
├── public/               # Static/generated public assets
├── astro.config.mjs      # Static Astro configuration
└── wrangler.jsonc        # Cloudflare Worker and custom domain
```'''
 b['Deployment and releases']=f'''Promote verified changes through a `dev` → `main` PR and keep `dev` updated. When dev also contains unrelated native work, follow the maintainer's reviewed website-only exception instead of publishing that work. The production Worker is `{app}`; the repository is `cloakyard/{app}` and the build root is `apps/site`.

| Setting | Value |
| --- | --- |
| Production branch | `main` |
| Build command | `{'npm run build' if app=='cloakdrop' else 'npm run verify'}` |
| Deploy command | `npx wrangler deploy` |
| Custom domain | `{url.split('//')[1].rstrip('/')}` |

Workers Builds uses dashboard-managed Git settings. Production deployment belongs to main; branch/PR builds must use preview versions. Never point a non-production branch at the production deploy command. Check the actual dashboard configuration and exact commit receipt rather than inferring deployment from `wrangler.jsonc`.

Keep watch paths aligned with `apps/site/**`, asset-sync sources, the root policy and imported `docs/air/**` assets. The full checkout is required. Native-only work must not be released by a website merge. CI validates/builds the website; no Cloudflare credentials belong in the repository.

For an explicitly authorized manual deployment, `npm run deploy` checks/builds as configured and publishes. For a local validation only, build first and run `npx wrangler deploy --dry-run`. After publication, verify the exact main build, public headers, routes and asset hashes. Native app releases and notarization are separate; the published [release notes](https://github.com/cloakyard/{app}/releases) own artifact and signing facts.
'''
 b['Contributing']='Read [AGENTS.md](../../AGENTS.md), [CLAUDE.md](../../CLAUDE.md) and [CONTRIBUTING.md](../../CONTRIBUTING.md). Follow the [family README standard](https://github.com/cloakyard/cloakyard/blob/main/docs/README_STANDARD.md), keep shared Air patterns portable, and record browser coverage without claiming unperformed hardware tests.\n\n[Buy me a coffee](https://ko-fi.com/sumitsahoo21) supports the project.'
 b['License']='Released under the [MIT License](../../LICENSE). Third-party components retain their own notices.\n\nBuilt by [Sumit Sahoo](https://github.com/sumitsahoo), part of [Cloakyard](https://cloakyard.com/).'
 p.write_text(f'# {name} website\n\n**The Air website for {name}.**\n\n[Website]({url}) · [Product README](../../README.md) · [Support](https://ko-fi.com/sumitsahoo21)\n\n'+'\n\n'.join('## '+h+'\n\n'+b[h].strip() for h in heads)+'\n')
