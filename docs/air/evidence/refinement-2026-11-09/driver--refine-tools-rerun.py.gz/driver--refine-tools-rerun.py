import subprocess, json, os, time, sys
from pathlib import Path
f=Path(os.environ['AIR_FAMILY_ROOT']);out=f/'evidence/refinement';results=[]
queue=sys.argv[1]; tasks=[]
def add(name,app,script,env=None):tasks.append((name,app,script,env or {}))
if queue=='shared':
 for n in ['family','privacy','dialogs','notices','presence']:add(n,'cloakyard',f'test-air-{n}.mjs')
 for engine in ['chromium','webkit']:
  add('editors-'+engine,'cloakyard','test-air-editors.mjs',{'AIR_BROWSER':engine})
  add('artwork-'+engine,'cloakyard','test-air-artwork-browsers.mjs',{'AIR_BROWSER':engine})
else:
 for engine in ['chromium','webkit']:
  add('img-tools-'+engine,'cloakimg','test-air-tool-states.mjs',{'AIR_BROWSER':engine,'BASE_URL':'http://127.0.0.1:8822','AIR_PROFILES':'[[390,844,16],[768,1024,16],[1024,768,16],[1280,720,16],[1440,900,16],[390,844,32],[1024,768,32]]'})
 for n in ['entry','batch']:add('img-'+n,'cloakimg',f'test-air-{n}.mjs',{'BASE_URL':'http://127.0.0.1:8822'})
 add('pdf-actions','cloakpdf','test-air-tool-actions.mjs',{'BASE_URL':'http://127.0.0.1:8821'})
 for n in ['sections','library','review','options','dates','logo-photo','contact-selects']:
  add('resume-'+n,'cloakresume',f'test-air-{n}.mjs',{'SITE_URL':'http://127.0.0.1:8823'})
tasks=[t for t in tasks if t[0]=='pdf-actions' or t[0].startswith('resume-')]
for name,app,script,extra in tasks:
 env=os.environ|{'AIR_EVIDENCE_DIR':str(out/name)}|extra
 start=time.time();cmd=['node','--preserve-symlinks-main',str(f/app/'scripts'/script)]
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=f/app,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,env=extra,exitCode=r.returncode,seconds=round(time.time()-start,2)))
 (out/('ui-'+queue+'-rerun.json')).write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
