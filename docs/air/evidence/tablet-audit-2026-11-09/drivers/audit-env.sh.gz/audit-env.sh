export AIR_FAMILY_ROOT=/Users/sumitsahoo/Developer/.air-mobile-2026-11-09
export PLAYWRIGHT_MODULE=/Users/sumitsahoo/.npm/_npx/9833c18b2d85bc59/node_modules/playwright/index.mjs
export PUPPETEER_MODULE=$AIR_FAMILY_ROOT/cloakpdf/node_modules/puppeteer-core/lib/puppeteer/puppeteer-core.js
export SHARP_MODULE=$AIR_FAMILY_ROOT/cloakpdf/node_modules/sharp/dist/index.mjs
export AIR_FAMILY_URLS=http://127.0.0.1:8620,http://127.0.0.1:8621,http://127.0.0.1:8624,http://127.0.0.1:8623,http://127.0.0.1:8625,http://127.0.0.1:8622
export AIR_EDITOR_URLS=http://127.0.0.1:8621,http://127.0.0.1:8622,http://127.0.0.1:8623
export AIR_PDF_FIXTURE=$AIR_FAMILY_ROOT/evidence/sample.pdf
export CHROME_PATH='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
