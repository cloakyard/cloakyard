source /Users/sumitsahoo/Developer/.air-mobile-2026-11-09/audit-env.sh
export AIR_FAMILY_URLS=http://127.0.0.1:8720,http://127.0.0.1:8721,http://127.0.0.1:8724,http://127.0.0.1:8723,http://127.0.0.1:8725,http://127.0.0.1:8722
export AIR_EDITOR_URLS=http://127.0.0.1:8721,http://127.0.0.1:8722,http://127.0.0.1:8723
export AIR_PDF_FIXTURE="$AIR_FAMILY_ROOT/evidence/live-sample.pdf"
export NODE_OPTIONS="--import=$AIR_FAMILY_ROOT/cloakyard/scripts/air-radius-audit.mjs"
