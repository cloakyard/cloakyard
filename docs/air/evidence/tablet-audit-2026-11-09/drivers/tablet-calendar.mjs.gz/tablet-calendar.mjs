import assert from 'node:assert/strict';import {mkdir,writeFile} from 'node:fs/promises';
const {chromium,webkit}=await import(process.env.PLAYWRIGHT_MODULE);const out='evidence/tablet/pdf-calendar';await mkdir(out,{recursive:true});const rows=[],errors=[];
for(const engine of ['chromium','webkit']){
 const b=await (engine==='webkit'?webkit.launch():chromium.launch({executablePath:process.env.CHROME_PATH,ignoreDefaultArgs:['--hide-scrollbars']}));
 try{for(const [width,height]of [[768,1024],[820,1180],[1024,768],[1180,820]])for(const theme of ['light','dark']){
  const p=await b.newPage({viewport:{width,height},hasTouch:true,colorScheme:theme,reducedMotion:'reduce',serviceWorkers:'block'});p.on('pageerror',e=>errors.push(e.message));await p.goto('http://127.0.0.1:8721');await p.locator('input[type=file]').first().setInputFiles('evidence/live-sample.pdf');await p.locator('img[alt="Page 1"]').waitFor();
  if(await p.locator('.editor-toolrail').count())await p.locator('.editor-toolrail').getByRole('button',{name:'Metadata',exact:true}).click();else{await p.getByRole('button',{name:'Open tools',exact:true}).click();await p.locator('.editor-mobile-sheet').getByRole('button',{name:'Metadata',exact:true}).click();}
  await p.locator('#metadata-creationDate').click();const picker=p.locator('.pdf-date-popover');await picker.waitFor();
  const actual=await picker.evaluate(e=>{const s=getComputedStyle(e);return{corners:[s.borderTopLeftRadius,s.borderTopRightRadius,s.borderBottomRightRadius,s.borderBottomLeftRadius],targets:[...e.querySelectorAll('[data-day]')].map(b=>{const r=b.getBoundingClientRect();return[r.width,r.height]}),overflow:e.scrollWidth>e.clientWidth+1}});
  assert.deepEqual(actual.corners,width<=360?['20px','20px','0px','0px']:Array(4).fill('12px'));assert(!actual.overflow);assert(actual.targets.every(([w,h])=>w>=43.9&&h>=43.9));
  if(true)await p.screenshot({path:`${out}/${engine}-${width}-${theme}.png`});await p.getByRole('button',{name:'Close date picker'}).click();await picker.waitFor({state:'hidden'});rows.push({engine,width,height,theme,...actual});await p.close();
 }}finally{await b.close();}
}
assert.deepEqual(errors,[]);await writeFile(`${out}/results.json`,JSON.stringify({rows,errors},null,2)+'\n');console.log(`${rows.length} built calendar layouts pass with real scrolling and 44px day targets.`);
