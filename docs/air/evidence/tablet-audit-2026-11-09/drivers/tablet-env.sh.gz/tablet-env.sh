source /Users/sumitsahoo/Developer/.air-mobile-2026-11-09/radius-env.sh
export AIR_TABLET_ROOT="$AIR_FAMILY_ROOT/evidence/tablet"
export AIR_SCOPE_LOG="$AIR_TABLET_ROOT/scope.ndjson"
export NODE_OPTIONS="--import=$AIR_FAMILY_ROOT/tablet-scope.mjs"
export AIR_PROFILES='[[768,1024],[820,1180],[1024,768],[1180,820]]'
export AIR_DIALOG_URLS="$AIR_EDITOR_URLS"
export AIR_PRIVACY_URLS="$AIR_FAMILY_URLS"
