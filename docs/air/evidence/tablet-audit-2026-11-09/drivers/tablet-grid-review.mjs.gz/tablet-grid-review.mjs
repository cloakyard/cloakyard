import sharp from './cloakpdf/node_modules/sharp/dist/index.mjs';
import {readdir,mkdir,access} from 'node:fs/promises';
await mkdir('evidence/tablet/review',{recursive:true});
const sets=[];
for(const [width,theme]of [[768,'light'],[768,'dark'],[820,'light'],[820,'dark'],[1024,'light'],[1024,'dark'],[1180,'light'],[1180,'dark']]){
 sets.push({name:`tools-${width}-${theme}`,folder:'img-tools',match:n=>n.startsWith(`${width}-16-${theme}-`)&&n.endsWith('-initial.png')});
 sets.push({name:`sections-${width}-${theme}`,folder:'resume-sections',match:n=>n.startsWith(`tablet-${width}-${theme}-`)});
}
for(const set of sets){
 const paths=(await readdir(`evidence/tablet/${set.folder}`)).filter(set.match).sort();
 for(let start=0;start<paths.length;start+=8){const composite=[];
  for(let i=0;i<Math.min(8,paths.length-start);i++){
   const name=paths[start+i],x=(i%4)*450,y=Math.floor(i/4)*560;
   let file=`evidence/tablet/${set.folder}/${name}`;
   if(set.folder==='img-tools-shots') for(const next of ['img-reflow-final-shots','img-crop-final-shots']) {const candidate=`evidence/tablet/${next}/${name}`;try{await access(candidate);file=candidate}catch{}}
   const im=await sharp(file).resize({width:440,height:525,fit:'inside'}).png().toBuffer({resolveWithObject:true});
   composite.push({input:im.data,left:x+Math.floor((440-im.info.width)/2),top:y+30});
   composite.push({input:Buffer.from(`<svg width="440" height="28"><text x="5" y="17" font-size="13">${name.replaceAll('&','&amp;')}</text></svg>`),left:x,top:y});
  }
  await sharp({create:{width:1800,height:1120,channels:3,background:'#ddd'}}).composite(composite).webp({quality:85}).toFile(`evidence/tablet/review/${set.name}-${start/8}.webp`);
 }
}
