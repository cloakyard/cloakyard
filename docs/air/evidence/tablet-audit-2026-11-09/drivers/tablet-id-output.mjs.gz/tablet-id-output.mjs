import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { chromium, webkit } from '/Users/sumitsahoo/.npm/_npx/9833c18b2d85bc59/node_modules/playwright/index.mjs';
import { createRequire } from 'node:module';
const { PDFDocument } = createRequire(new URL('./cloakpdf/package.json', import.meta.url))('@pdfme/pdf-lib');
import { selectEditorTool } from './cloakimg/scripts/air-editor-driver.mjs';
const out='evidence/tablet/img-id-output';
await mkdir(out,{recursive:true});
const rows=[],errors=[];
for(const engine of ['chromium','webkit']){
 const browser=await (engine==='webkit'?webkit.launch():chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}));
 try{for(const [width,height]of [[768,1024],[1024,768]])for(const theme of ['light','dark']){
  const context=await browser.newContext({viewport:{width,height},hasTouch:true,colorScheme:theme,reducedMotion:'reduce'});
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
  await page.goto('http://127.0.0.1:8722');
  await page.addStyleTag({content:'html{font-size:32px}'});
  await page.locator('input[type=file]').first().setInputFiles('cloakimg/scripts/fixtures/orange.webp');
  await page.locator('.editor-topbar [aria-label=Export]:not(:disabled)').waitFor();
  await selectEditorTool(page,'ID photo sheet');
  const downloadPromise=page.waitForEvent('download');
  await page.getByRole('button',{name:'Save PDF',exact:true}).click();
  const download=await downloadPromise,path=`${out}/${engine}-${width}-${theme}.pdf`;
  await download.saveAs(path);
  const pdf=await PDFDocument.load(await readFile(path));
  assert.equal(pdf.getPageCount(),1);
  const size=pdf.getPage(0).getSize();
  assert(Math.abs(size.width-288)<1&&Math.abs(size.height-432)<1,JSON.stringify(size));
  const popupPromise=page.waitForEvent('popup');
  await page.getByRole('button',{name:'Print',exact:true}).click();
  const popup=await popupPromise;
  await popup.waitForFunction(()=>document.querySelector('#sheet')?.naturalWidth>0);
  const print=await popup.evaluate(()=>({title:document.title,opener:window.opener===null,width:document.querySelector('#sheet').naturalWidth,height:document.querySelector('#sheet').naturalHeight,style:document.querySelector('style').textContent}));
  assert.equal(print.title,'ID photo sheet');assert(print.opener);
  assert(print.style.includes('101.6mm 152.4mm'));
  rows.push({engine,width,height,theme,font:32,pdf:{pages:1,...size},print});
  await context.close();
 }}finally{await browser.close()}
}
await writeFile(`${out}/results.json`,JSON.stringify({rows,errors},null,2)+'\n');
assert.equal(errors.length,0);console.log(`${rows.length} real PDF downloads and prepared print windows passed`);
