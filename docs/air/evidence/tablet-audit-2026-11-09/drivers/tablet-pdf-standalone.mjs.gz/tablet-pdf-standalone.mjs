import assert from 'node:assert/strict';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
const {chromium,webkit}=await import(process.env.PLAYWRIGHT_MODULE);
const tools=[['merge','Merge PDFs'],['images-to-pdf','Images to PDF'],['extract-images','Extract Images'],['pdf-password','PDF Password'],['compare-pdf','Compare PDFs'],['digital-signature','Digital Signature'],['ask-pdf','Ask your PDF']];
const out='evidence/tablet/pdf-standalone';await mkdir(out,{recursive:true});const rows=[],errors=[];
const pdf=await readFile('evidence/live-sample.pdf'),png=await readFile('cloakpdf/public/icons/apple-touch-icon.png');
for(const engine of ['chromium','webkit']){
const b=await (engine==='webkit'?webkit.launch():chromium.launch({executablePath:process.env.CHROME_PATH}));
try{for(const [width,height] of [[768,1024],[820,1180],[1024,768],[1180,820]])for(const theme of ['light','dark'])for(const [id,title]of tools){
 const p=await b.newPage({viewport:{width,height},hasTouch:true,colorScheme:theme,reducedMotion:'reduce',serviceWorkers:'block'});p.on('pageerror',e=>errors.push({engine,width,theme,id,error:e.message}));await p.goto('http://127.0.0.1:8721');
 await p.getByRole('heading',{name:title,exact:true}).click();await p.getByRole('heading',{level:1,name:title,exact:true}).waitFor();
 async function check(state){await p.evaluate(()=>document.fonts.ready);await p.waitForTimeout(180);const m=await p.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth+1,small:[...document.querySelectorAll('button')].filter(e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>1&&r.height>1&&s.visibility!=='hidden'&&!e.closest('[hidden],[inert],.sr-only')&&(r.width<43.5||r.height<43.5)}).map(e=>e.ariaLabel||e.textContent?.trim())}));rows.push({engine,width,height,theme,id,state,...m});await p.screenshot({path:`${out}/${engine}-${width}-${theme}-${id}-${state}.png`,fullPage:true});assert(!m.overflow,JSON.stringify(rows.at(-1)));assert.deepEqual(m.small,[],JSON.stringify(rows.at(-1)));}
 await check('empty');
 if(id!=='ask-pdf'){
  const inputs=p.locator('main input[type=file]');const f={name:'Tablet sample.pdf',mimeType:'application/pdf',buffer:pdf};
  if(id==='images-to-pdf') await inputs.first().setInputFiles({name:'Tablet image.png',mimeType:'image/png',buffer:png});
  else if(id==='merge') await inputs.first().setInputFiles([f,{...f,name:'Second tablet sample.pdf'}]);
  else {await inputs.first().setInputFiles(f);if(id==='compare-pdf')await p.locator('[data-compare-side="1"] input[type=file]').setInputFiles({...f,name:'Second tablet sample.pdf'});}
  await check('selected');
 }
 await p.close();console.log(engine,width,theme,id);
}}finally{await b.close();await writeFile(`${out}/results.json`,JSON.stringify({rows,errors},null,2)+'\n');}}
assert.deepEqual(errors,[]);console.log(`${rows.length} standalone tablet states passed`);
