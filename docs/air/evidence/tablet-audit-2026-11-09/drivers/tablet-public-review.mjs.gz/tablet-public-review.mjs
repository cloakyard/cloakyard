import sharp from './cloakpdf/node_modules/sharp/dist/index.mjs';import {mkdir,access} from 'node:fs/promises';
await mkdir('evidence/tablet/review',{recursive:true});
for(const width of [768,820,1024,1180])for(const theme of ['light','dark'])for(const part of ['top','footer']){
 const images=[];let i=0;
 for(const app of ['cloakyard','cloakpdf','cloakdrop','cloakresume','cloakroll','cloakimg']){
  const path=`evidence/tablet/public-shots/${app}-${width}-${theme}.png`;try{await access(path)}catch{continue}
  const m=await sharp(path).metadata();const h=Math.min(m.height,width<500?900:width<900?1024:900);
  const im=await sharp(path).extract({left:0,top:part==='top'?0:m.height-h,width:m.width,height:h}).resize({width:590,height:510,fit:'inside'}).png().toBuffer({resolveWithObject:true});
  const x=(i%3)*600,y=Math.floor(i/3)*550;i++;
  images.push({input:im.data,left:x+Math.floor((590-im.info.width)/2),top:y+30});images.push({input:Buffer.from(`<svg width="590" height="25"><text x="10" y="19" font-size="16">${app} ${width} ${theme} ${part}</text></svg>`),left:x,top:y});
 }
 if(images.length)await sharp({create:{width:1800,height:1100,channels:3,background:'#ddd'}}).composite(images).webp({quality:86}).toFile(`evidence/tablet/review/public-${width}-${theme}-${part}.webp`);
}
