import sharp from './cloakpdf/node_modules/sharp/dist/index.mjs';
import {mkdir,access} from 'node:fs/promises';
await mkdir('evidence/tablet/review',{recursive:true});
for(const view of ['editor','controls','dialog'])for(const width of [768,820,1024,1180]){
 const images=[];let i=0;
 for(const app of ['pdf','img','resume'])for(const theme of ['light','dark']){
  const name=`${app}-${width}-${theme}-${view}`,path=`evidence/tablet/final-chromium/${name}.png`,x=Math.floor(i/2)*600,y=(i%2)*550;i++;
  try{await access(path)}catch{continue}
  const im=await sharp(path).resize({width:590,height:510,fit:'inside'}).png().toBuffer({resolveWithObject:true});
  images.push({input:im.data,left:x+Math.floor((590-im.info.width)/2),top:y+30});
  images.push({input:Buffer.from(`<svg width="590" height="25"><text x="10" y="19" font-size="16">${name}</text></svg>`),left:x,top:y});
 }
 if(images.length)await sharp({create:{width:1800,height:1100,channels:3,background:'#ddd'}}).composite(images).webp({quality:90}).toFile(`evidence/tablet/review/${width}-${view}.webp`);
}
