// Audit-only profile/capture adapter. Production sources and assertions are unchanged.
import { registerHooks } from 'node:module';
import { createHash } from 'node:crypto';
import { appendFileSync } from 'node:fs';
const sizes = [[768,1024],[820,1180],[1024,768],[1180,820]];
const entries = new Set(['test-air-family.mjs','test-air-privacy.mjs','test-air-dialogs.mjs','test-air-notices.mjs','test-air-sections.mjs','test-air-library.mjs','test-air-review.mjs','test-air-options.mjs','test-air-dates.mjs','test-air-colour.mjs','test-air-logo-photo.mjs','test-air-contact-selects.mjs','test-air-entry.mjs','test-air-batch.mjs','test-air-artwork-browsers.mjs','test-air-editors.mjs','test-air-tool-states.mjs','editor-navigation.e2e.ts','editor-collections.e2e.ts']);
registerHooks({load(url, context, nextLoad) {
 const result = nextLoad(url, context), name = url.split('/').at(-1);
 if(!entries.has(name) || !url.includes('/Developer/')) return result;
 const original = String(result.source); let source=original;
 source=source.replace(/const sizes = \[[\s\S]*?\n\s*\];/, `const sizes = ${JSON.stringify(sizes)};`);
 if(name==='test-air-dates.mjs') source=source.replace(/const sizes =[\s\S]*?;\nconst fixture/,`const sizes = ${JSON.stringify(sizes)};\nconst fixture`);
 if(name==='test-air-artwork-browsers.mjs') source=source.replace(/const sizes =[\s\S]*?;\nconst evidence/,`const sizes = ${JSON.stringify(sizes)};\nconst evidence`);
 // These are tablet touch profiles even when their width crosses a desktop breakpoint.
 source=source.replace(/hasTouch: (width|w) (?:<=|<) (?:1024|1100)/g,'hasTouch: true');
 if(name==='editor-navigation.e2e.ts') {
  source=source.replace(/for \(const \[width, height\] of \[\n    \[1440, 900\],[\s\S]*?\n  \]\) \{/,`for (const [width, height] of ${JSON.stringify(sizes)}) {`);
  source=source.replace('registryRows.push({ tool:', 'await page.screenshot({path: resolve(output, `tool-${width}-${theme}-${tool.id}.png`)});\n        registryRows.push({ tool:');
 }
 if(name==='test-air-sections.mjs') source=source.replace('layouts.push({ w, h, theme, text, state, section:', 'if(text===16 && state==="populated") await page.screenshot({path: `${out}/tablet-${w}-${theme}-${name.replaceAll(/[^a-z0-9]+/gi,"-")}.png`});\n            layouts.push({ w, h, theme, text, state, section:');
 if(name==='test-air-library.mjs') source=source.replace('layouts.push({ w, h, theme, text, draft, state,', 'if(text===16 && draft==="populated") await page.screenshot({path: `${out}/tablet-${w}-${theme}-${state}.png`});\n            layouts.push({ w, h, theme, text, draft, state,');
 if(['test-air-review.mjs','test-air-options.mjs'].includes(name)) source=source.replace('records.push({ id,', 'if(text===16 && coarse) await p.screenshot({path: `${out}/tablet-${id}.png`});\n            records.push({ id,');
 if(process.env.AIR_SCOPE_LOG) appendFileSync(process.env.AIR_SCOPE_LOG, JSON.stringify({name,url,sizes,originalSha256:createHash('sha256').update(original).digest('hex'),scopedSha256:createHash('sha256').update(source).digest('hex')})+'\n');
 return {...result,source};
}});
